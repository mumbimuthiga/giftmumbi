Installation of ActiveXperts SMS Messaging Server 4.1 (4.1.8.0701 -Newest version of 4.1)
------------------------------------------------------------------------------------------>>

DO THIS BEFORE YOU START THE INSTALLATION!
1. Turn off your internet connection.
2. Set your system date to 01.05.2020 (1st of May 2020)

NOW YOU CAN START INSTALLING
3. Begin the installation of asmssrvr410.exe. Do not enter any serial number!

WHEN THE INSTALLATION IS COMPLETE
4. Copy all the "info" files from the crack folder to your Windows-folder. Typically C:/Windows
5. Return your system time back to current. (The correct date)
6. Restart your computer.

Now ActiveXperts SMS Messaging Server 4.1 will work until 01.05.2020.
The "About" menu always show that you have 30 days left. Don't pay attention.