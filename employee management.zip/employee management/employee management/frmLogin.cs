﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace employee_management
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
             if (txtUserName.Text.Replace(" ", "") == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtUserName.Focus();
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPassword.Focus();
            }
            else
            {      //creates an object called connect from the connection class which connects to the database
                conn connect = new conn();
                string query = "SELECT * FROM  user WHERE user_name='" + txtUserName.Text.ToString() + "' AND password='" + txtPassword.Text.ToString() + "' AND Status=1";

                //open connection
                if (connect.OpenConnection() == true)
                {
                    //create command and assign the query and connection from the constructor
                    MySqlCommand cmd = new MySqlCommand(query, connect.connect);
                    MySqlDataReader dataReader = cmd.ExecuteReader();

                    //Read the data and store them in the list
                    if (dataReader.Read())
                    {
                        //list[0].Add(dataReader["id"] + "");
                        //list[1].Add(dataReader["name"] + "");
                        if (dataReader["user_name"].ToString() == txtUserName.Text && dataReader["password"].ToString() == txtPassword.Text)
                        {
                            Sessions.username = dataReader["user_name"].ToString();
                            Sessions.prev = dataReader["priviledges"].ToString();
                            Sessions.userID = dataReader["user_id"].ToString();
                            Sessions.loginTime = DateTime.Now.ToString();
                            dashboard dash = new dashboard();
                            dash.Visible = true;
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Username/Password Mismatch!\nPlease Try again!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            txtUserName.Text = "";
                            txtPassword.Text = "";
                            txtUserName.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Username/Password Mismatch!\nPlease Try again!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtUserName.Text = "";
                        txtPassword.Text = "";
                        txtUserName.Focus();
                    }

                    //close Data Reader
                    dataReader.Close();


                    //close connection
                    connect.CloseConnection();
                }
            }

        }
        }
       }
  

