﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace employee_management
{
    public partial class frmEmployee : Form
    {
        public String query;
        public frmEmployee()
        {
            InitializeComponent();
        }
        private void cleanData()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            dtPicDOB.Value = DateTime.Now;
            dtPicHD.Value = DateTime.Now;
            rbtnMale.Checked = true;
            rbtnFemale.Checked = false;
            txtEmployeeNumber.Text = "";
            txtTitle.Text = "";
            txtFirstName.Focus();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtFirstName.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFirstName.Focus();
            }
            else if (txtLastName.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLastName.Focus();
            }
            else if (txtEmployeeNumber.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmployeeNumber.Focus();
            }
            else if (txtTitle.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTitle.Focus();
            }
            else
            {
                String gnder;

                if (rbtnFemale.Checked == true)
                {
                    gnder = "Female";
                }
                else
                {
                    gnder = "Male";
                }

                query = "INSERT INTO employees VALUES('" + txtEmployeeNumber.Text + "','" + dtPicDOB.Value.ToString("yyyy-MM-dd") + "','" + txtFirstName.Text + "','" + txtLastName.Text + "','" + gnder + "','" + dtPicHD.Value.ToString("yyyy-MM-dd") + "','" + txtTitle.Text +"')";
                conn cn = new conn();
                if (cn.OpenConnection() == true)
                {
                    if (MessageBox.Show("Are you sure you want to save record?", "MLEMS Employee management system", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MySqlCommand cmd = new MySqlCommand(query, cn.connect);
                        cmd.ExecuteNonQuery();

                        cleanData();
                        MessageBox.Show("Records Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Records not Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtFirstName.Focus();
                    }
                }
                cn.CloseConnection();
            }
        }
             private void AssignUserID()
        {
            conn cn = new conn();
            if (cn.OpenConnection() == true)
            {
                query = "SELECT * FROM employees ORDER BY emp_no DESC";
                MySqlCommand cmd = new MySqlCommand(query, cn.connect);
                MySqlDataReader dataReader = cmd.ExecuteReader();
                //Read the data and store them in the list
                //this.cboStaffNo.Items.Clear();
                int stffNo;
                if (dataReader.Read())
                {
                    if (dataReader["emp_no"].ToString().Replace(" ", "") != "")
                    {

                        stffNo = Convert.ToInt32((dataReader["emp_no"].ToString().Substring(4)));
                        if (stffNo < 9)
                        {
                            txtEmployeeNumber.Text = "EMP/000" + (stffNo + 1);
                        }
                        else if (stffNo >= 9 && stffNo < 99)
                        {
                            txtEmployeeNumber.Text = "EMP/00" + (stffNo + 1);
                        }
                        else if (stffNo >= 99 && stffNo < 999)
                        {
                            txtEmployeeNumber.Text = "EMP/0" + (stffNo + 1);
                        }
                        else
                        {
                            txtEmployeeNumber.Text = "EMP/" + (stffNo + 1);
                        }

                        //MessageBox.Show(txtStaffNo.Text);
                      }

                      }
                   else
                     {
                    txtEmployeeNumber.Text = "EMP/0001";
                    }
                    cn.CloseConnection();
                }
               }

             private void frmEmployee_Load(object sender, EventArgs e)
             {
                 AssignUserID();
             }



        }
    }


