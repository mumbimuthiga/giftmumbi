﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace employee_management
{
    public partial class frmUser : Form
    {
        public String query;
        public frmUser()
        {
            InitializeComponent();
        }

        private void cleanData()
        {
            txtUserId.Text = "";
            txtUserName.Text = "";
            txtPhoneNumber.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            cboPriviledges.Text = "";
            AssignUserID();
            chckStatus.CheckState = CheckState.Unchecked;
            txtUserName.Focus();
        }
        private void AssignUserID()
        {
            conn cn = new conn();
            if (cn.OpenConnection() == true)
            {
                query = "SELECT * FROM user ORDER BY user_id DESC";
                MySqlCommand cmd = new MySqlCommand(query, cn.connect);
                MySqlDataReader dataReader = cmd.ExecuteReader();
                //Read the data and store them in the list
                //this.cboStaffNo.Items.Clear();
                int stffNo;
                if (dataReader.Read())
                {
                    if (dataReader["user_id"].ToString().Replace(" ", "") != "")
                    {

                        stffNo = Convert.ToInt32((dataReader["user_id"].ToString().Substring(4)));
                        if (stffNo < 9)
                        {
                            txtUserId.Text = "EMP/000" + (stffNo + 1);
                        }
                        else if (stffNo >= 9 && stffNo < 99)
                        {
                            txtUserId.Text = "EMP/00" + (stffNo + 1);
                        }
                        else if (stffNo >= 99 && stffNo < 999)
                        {
                            txtUserId.Text = "EMP/0" + (stffNo + 1);
                        }
                        else
                        {
                            txtUserId.Text = "EMP/" + (stffNo + 1);
                        }

                        //MessageBox.Show(txtStaffNo.Text);
                      }

                      }
                   else
                     {
                    txtUserId.Text = "EMP/0001";
                    }
                    cn.CloseConnection();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            long phone;
            string phn = txtPhoneNumber.Text.Replace("+", "").Trim().ToString();
            if (txtUserId.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserId.Focus();
            }
            else if (txtUserName.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserName.Focus();
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Focus();
            }
            else if (txtConfirmPassword.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtConfirmPassword.Focus();
            }
            else if (txtConfirmPassword.Text != txtPassword.Text)
            {
                MessageBox.Show("Password mismatch!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Text = "";
                txtConfirmPassword.Text = "";
                txtPassword.Focus();
            }
            else if (cboPriviledges.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboPriviledges.Focus();
            }
            else if (txtPhoneNumber.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPhoneNumber.Focus();
            }
            else if (!long.TryParse(phn, out phone))
            {
                MessageBox.Show("Invalid Phone Number!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPhoneNumber.Focus();
            }
            else if (!txtPhoneNumber.Text.Contains("+"))
            {
                MessageBox.Show("Invalid Phone Number!","MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtPhoneNumber.Focus();
            }
                else
                {
                    int sts;
                    if (chckStatus.CheckState == CheckState.Checked)
                    {
                        sts = 1;
                    }
                    else
                    {
                        sts = 0;
                    }
                    query = "INSERT INTO user VALUES('" + txtUserId.Text + "','" + txtUserName.Text + "','" + txtPassword.Text + "','" + cboPriviledges.Text + "','" + sts + "','" + txtPhoneNumber.Text + "')";
                    conn cn = new conn();
                    if (cn.OpenConnection() == true)
                    {
                        if (MessageBox.Show("Are you sure you want to save record?", "MLEMS Employee management system", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            MySqlCommand cmd = new MySqlCommand(query, cn.connect);
                            cmd.ExecuteNonQuery();

                            cleanData();
                            MessageBox.Show("Records Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Records not Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            txtUserId.Focus();
                        }
                    }
                    cn.CloseConnection();
                }



            }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void frmUser_Load(object sender, EventArgs e)
        {
            AssignUserID();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmployeeNumber_Click(object sender, EventArgs e)
        {

        }
        }
    }

