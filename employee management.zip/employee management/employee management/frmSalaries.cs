﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace employee_management
{
    public partial class frmSalaries : Form
    {
        String query;
        public frmSalaries()
        {
            InitializeComponent();
        }

        private void cleanData()
        {
            cboEmpNo.Text = "";
            txtSalaryAmount.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmail.Text = "";
        }
        private void addProgram()
        {
      
            query = " SELECT * FROM employees";
            conn cn = new conn();
            if (cn.OpenConnection() == true)
            {
                MySqlCommand command = new MySqlCommand(query, cn.connect);
                MySqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    cboEmpNo.Items.Add(reader.GetString("emp_no"));

                }

            }
            cn.CloseConnection();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             if (cboEmpNo.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboEmpNo.Focus();
            }
             else if (txtSalaryAmount.Text == "")
             {
                 MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 txtSalaryAmount.Focus();
             }
             else if (txtFirstName.Text == "")
             {
                 MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 txtFirstName.Focus();
             }
             else if (txtLastName.Text == "")
             {
                 MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 txtLastName.Focus();
             }
             else if (txtEmail.Text == "")
             {
                 MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 txtEmail.Focus();
             }


             query = "INSERT INTO salary VALUES('" + txtFirstName.Text + "','" + txtLastName.Text + "','" + txtSalaryAmount.Text+"','"+ cboEmpNo.Text+"','"+txtEmail+"')";
                conn cn = new conn();
                if (cn.OpenConnection() == true)
                {
                    if (MessageBox.Show("Are you sure you want to save record?", "MLEMS Employee management system", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MySqlCommand cmd = new MySqlCommand(query, cn.connect);
                        cmd.ExecuteNonQuery();

                        cleanData();
                        MessageBox.Show("Records Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Records not Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        cboEmpNo.Focus();
                    }
                }
                cn.CloseConnection();
            }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void frmSalaries_Load(object sender, EventArgs e)
        {
            addProgram();
        }
        }
    }

