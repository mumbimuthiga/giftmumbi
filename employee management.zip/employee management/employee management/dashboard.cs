﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace employee_management
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frmEmployee emp = new frmEmployee();
            emp.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            frmDepartment dep = new frmDepartment();
            dep.Visible = true;

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            frmSalaries salo = new frmSalaries();
            salo.Visible = true;

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            frmUser user = new frmUser();
            user.Visible = true;

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            frmMessage mess = new frmMessage();
            mess.Visible = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Left -= 5;
            pictureBox2.Left -= 5;
            pictureBox3.Left -= 5;
            pictureBox4.Left -= 5;
            pictureBox5.Left -= 5;
            if (pictureBox1.Left <= 110)
            {
                timer1.Stop();
                timer2.Start();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            panel2.Top -= 33;
            panel3.Top -= 33;
            if (panel2.Top <= 336)
            {
                timer2.Stop();
                //timer3.Start();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString("hh:mm tt");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            frmLogin frmlg = new frmLogin();
            frmlg.Visible = true;
            Application.Exit();
        }

        private void btnUser_Click(object sender, EventArgs e)
        {
            timer1.Start();
            btnUser.Hide();
            lblUserName.Hide();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
            lblUserName.Text = "WELCOME " + Sessions.username;
            //lblLoginTime.Text = "(Logged In: " + Sessions.loginTime + ")";
        }
    }
}
