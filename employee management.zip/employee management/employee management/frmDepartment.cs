﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace employee_management
{
    public partial class frmDepartment : Form
    {
        public String query;
        public frmDepartment()
        {
            InitializeComponent();
        }
         private void cleanData()
        {
            txtDepNo.Text = "";
            txtDepName.Text = "";
            txtRoom.Text = "";
            txtDescription.Text = "";
            txtDepNo.Focus();
         }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtDepNo.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDepNo.Focus();
            }
            else if (txtDepName.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDepName.Focus();
            }
            else if (txtRoom.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRoom.Focus();
            }
            else if (txtDescription.Text == "")
            {
                MessageBox.Show("Ensure all fields are filled!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtRoom.Focus();
            }
        

             query = "INSERT INTO departments VALUES('" + txtDepNo.Text + "','" + txtDepName.Text + "','" + txtRoom.Text + "','" + txtDescription.Text +"')";
                conn cn = new conn();
                if (cn.OpenConnection() == true)
                {
                    if (MessageBox.Show("Are you sure you want to save record?", "MLEMS Employee management system", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        MySqlCommand cmd = new MySqlCommand(query, cn.connect);
                        cmd.ExecuteNonQuery();

                        cleanData();
                        MessageBox.Show("Records Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Records not Saved!", "MLEMS Employee management system", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtDepNo.Focus();
                    }
                }
                cn.CloseConnection();
            }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void frmDepartment_Load(object sender, EventArgs e)
        {

        }

        }
    }

