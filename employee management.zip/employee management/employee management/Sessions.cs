﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace employee_management
{
    class Sessions
    {
        public static string username = null;
        public static string loginTime = null;
        public static string prev = null;
        public static string userID = null;
        public static string phoneNo = null;
        public Sessions()
        {
            username = null;
            loginTime = null;
        }
    }
    }

